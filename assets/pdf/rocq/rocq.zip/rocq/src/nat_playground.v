From Verao.Prelude Require Import Checks.
Module my_nat.
  Inductive nat : Type :=
    | Z : nat
    | S : nat -> nat.

  Check nat_ind.

  Fixpoint add (n m : nat) : nat :=
  match n with
  | Z => m
  | S n' => S (add n' m)
  end.

  Lemma add_Z_l :
    forall (m : nat), add Z m = m.
  Proof.
    intro m.
    simpl.
    reflexivity.
  Qed.

  Lemma add_Z_r :
    forall (n : nat), add n Z = n.
  Proof.
  Admitted.
End my_nat.
